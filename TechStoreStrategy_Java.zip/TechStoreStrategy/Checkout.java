public class Checkout {

    private Pagamento estrategiaPagamento;

    public void setPagamento(Pagamento pagamento) {
        this.estrategiaPagamento = pagamento;
    }

    public void finalizarCompra(double valor) {
        if (estrategiaPagamento == null) {
            System.out.println("Escolha uma forma de pagamento.");
            return;
        }

        estrategiaPagamento.pagar(valor);
    }
}
