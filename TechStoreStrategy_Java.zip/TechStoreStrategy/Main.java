import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Checkout checkout = new Checkout();

        System.out.println("===== TECHSTORE =====");
        System.out.println("Valor da compra: R$ 250.00");
        System.out.println("\nEscolha a forma de pagamento:");
        System.out.println("1 - Pix");
        System.out.println("2 - Cartao de credito");
        System.out.println("3 - Boleto");
        System.out.print("Opcao: ");

        int opcao = scanner.nextInt();

        switch (opcao) {
            case 1:
                checkout.setPagamento(new PagamentoPix());
                break;
            case 2:
                checkout.setPagamento(new PagamentoCartao());
                break;
            case 3:
                checkout.setPagamento(new PagamentoBoleto());
                break;
            default:
                System.out.println("Opcao invalida.");
                scanner.close();
                return;
        }

        checkout.finalizarCompra(250.00);
        scanner.close();
    }
}
