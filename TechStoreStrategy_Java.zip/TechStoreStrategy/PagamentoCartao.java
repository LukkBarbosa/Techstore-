public class PagamentoCartao implements Pagamento {

    @Override
    public void pagar(double valor) {
        System.out.println("Pagamento realizado via Cartao.");
        System.out.println("Valor: R$ " + valor);
        System.out.println("Cartao aprovado!");
    }
}
