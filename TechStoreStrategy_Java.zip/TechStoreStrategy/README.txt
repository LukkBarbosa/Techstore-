TECHSTORE - PADRAO STRATEGY (Java)

Arquivos:
- Main.java: menu e execucao do programa
- Pagamento.java: interface comum
- PagamentoPix.java: estrategia Pix
- PagamentoCartao.java: estrategia Cartao
- PagamentoBoleto.java: estrategia Boleto
- Checkout.java: contexto que utiliza a estrategia

Como executar:
1. Abra a pasta em uma IDE Java (IntelliJ IDEA, Eclipse ou VS Code).
2. Execute Main.java.
3. Escolha 1, 2 ou 3 no console.

Para demonstrar o Debug:
- Coloque breakpoint no Main, na linha checkout.setPagamento(...).
- Coloque breakpoint em Checkout.java na linha estrategiaPagamento = pagamento.
- Coloque breakpoint na linha estrategiaPagamento.pagar(valor).
- Coloque breakpoint dentro do metodo pagar() de uma das estrategias.
