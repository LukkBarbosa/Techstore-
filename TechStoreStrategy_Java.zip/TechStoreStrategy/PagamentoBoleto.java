public class PagamentoBoleto implements Pagamento {

    @Override
    public void pagar(double valor) {
        System.out.println("Pagamento realizado via Boleto.");
        System.out.println("Valor: R$ " + valor);
        System.out.println("Boleto gerado com sucesso!");
    }
}
