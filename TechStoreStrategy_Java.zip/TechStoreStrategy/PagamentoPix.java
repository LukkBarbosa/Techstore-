public class PagamentoPix implements Pagamento {

    @Override
    public void pagar(double valor) {
        System.out.println("Pagamento realizado via Pix.");
        System.out.println("Valor: R$ " + valor);
        System.out.println("Pix processado com sucesso!");
    }
}
